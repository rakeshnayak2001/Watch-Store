<footer>
    <span class="spanFooterTitle"><b>INTERNATIONAL PREMIUM - SMARTWATCH STORE</b></span> <br>
    <span id="spanFooter">SERVING CUSTOMERS WITH QUALITY</span> 
    
</footer>