<footer>
    <span class="spanFooterTitle"><b>THỰC TẬP WEB - CỬA HÀNG ĐỒNG HỒ ONLINE</b></span> <br>
    <span id="spanFooter">Students' Informations</span> 
    <script language="javascript">
        showFooterDetails();
    </script>
</footer>