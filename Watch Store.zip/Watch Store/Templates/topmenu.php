<div class="divTopMenu">
    <nav>
        <ul id="ulTopMenu"> 
            <li><a href="index.php">Home page</a></li>
            <li><a href="products.php">Product</a></li>
            <li><a href="contact.php">Contact</a></li>
            <li><a href="search.php">Search</a></li>
            <li><a href="checkorder.php">Check your order</a></li>
        </ul>
    </nav>
</div>